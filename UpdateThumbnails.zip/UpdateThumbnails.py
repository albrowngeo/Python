"""-------------------------------------------------------------------------------
Name:       UpdateThumbnails.py
Purpose:    Match items in ArcGIS Online through a lookup csv. Apply set thumbnail.

Author:     Alexander J Brown - Solution Engineer Esri (alexander_brown@esri.com)
-------------------------------------------------------------------------------"""
# import all the necessary modules
from arcgis.gis import GIS
import logging
import csv
import os
import sys
import time
import configparser
from logging import handlers


# Logging function to establish where script logging will occur.
def logging_start(name):
    try:
        master_log = logging.getLogger()
        # Change logging level here (CRITICAL, ERROR, WARNING, INFO or DEBUG)
        master_log.setLevel(logging.INFO)

        if name.endswith('.py'):
            fname = name[:-3]
        else:
            fname = name
            pass

        # Logging variables
        max_bytes = 250000
        backup_count = 1  # Max number appended to log files when MAX_BYTES reached
        log_file = os.path.abspath(os.path.dirname(sys.argv[0])) + os.sep + 'Logs' + os.sep + fname + '.txt'

        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

        fh = logging.handlers.RotatingFileHandler(log_file, 'a', max_bytes, backup_count)
        # Change logging level here for log file (CRITICAL, ERROR, WARNING, INFO or DEBUG)
        fh.setLevel(logging.INFO)
        fh.setFormatter(formatter)
        master_log.addHandler(fh)

        return master_log

    except:
        error = 'Error: %s %s' % (sys.exc_info()[0], sys.exc_info()[1])
        raise error


# Parse through config file for all license types, workspace, output oracle table.
def get_config(location, name):
    try:
        config = configparser.ConfigParser()
        format_name = name[:-3]
        config.read(location + os.sep + format_name + '.cfg')
        agol_url = config.get('URL', 'agol_org')
        user_name = config.get('Credentials', 'user_name')
        pass_word = config.get('Credentials', 'pass_word')
        csv_file = config.get('TextFile', 'csv')
        logger.info('Parsed from config file: arcgisonline org, user_name, pass_word, csv location.')
        return agol_url, user_name, pass_word, csv_file

    except configparser.Error as error:
        logger.critical('Check get config function: %s' % error)
        logger.critical('Check your config file!')


# Main script to call functions above and
if __name__ == "__main__":
    scriptLocation = os.path.abspath(os.path.dirname(sys.argv[0])) + os.sep + 'Config'
    scriptName = os.path.basename(sys.argv[0])

    # Start Logging
    logger = logging_start(scriptName)
    logger.info(('**** Script: %s, was started at %s. ****' % (scriptName, time.strftime('%X %x %Z'))))

    # Parse through config file
    arcgisonline, username, pass1, csv_name = get_config(scriptLocation, scriptName)
    csv_path = os.path.abspath(os.path.dirname(sys.argv[0])) + os.sep + csv_name
    images_path = os.path.abspath(os.path.dirname(sys.argv[0])) + os.sep + 'Images'

    # login to an existing arcgis online organization
    gis = GIS(arcgisonline, username, pass1)
    logger.info('Successfully connected to %s' % gis)

    # load itemIDs and thumbnail paths from csv into a dictionary
    items = []

    with open(csv_path, newline="") as f:
        reader = csv.reader(f, delimiter=',')
        for row in reader:
            items.append(row)

    # lookup layer name from item id, display thumbnail, update thumbnail, display new thumbnail
    for row in items[1:]:
        try:
            item = gis.content.get(row[1])
            new_thumbnail = images_path + os.sep + row[2]
            if os.path.isfile(new_thumbnail):
                item.update(thumbnail=new_thumbnail)
                logger.info('Changed thumbnail for %s' % item.title)
            else:
                logger.error('Thumbnail %s, does not exist in images directory: %s' % (row[2],images_path))
        except RuntimeError as e:
            logger.error('Item does not exist. Check Row %s. %s' % (row, e))

    logger.info(('---- Script: %s, was completed at %s. ----' % (scriptName, time.strftime('%X %x %Z'))))
    print(('---- Script: %s, was completed at %s. ----' % (scriptName, time.strftime('%X %x %Z'))))