"""-------------------------------------------------------------------------------
Name:       AGO_Pro_Update.py
Purpose:    Overwrite services in ArcGIS Online or Enterprise utilizing ArcGIS Pro Maps
Verion:     1.0 Base version.  For ArcGIS Online, publishes Hosted Feature Services only.
            For ArcGIS Enterprise, it depends on where the data sits and how that data is
            registered with ArcGIS Server.  If you have a connection to an SDE Enterprise
            Geodatabase registed, this will be a non-Hosted feature service.  If you do not
            have the connection registed, it will be Hosted.
            how your data is registered within ArcGIS Server--app
Author:     Alexander J Brown - Solution Engineer Esri (alexander_brown@esri.com)
-------------------------------------------------------------------------------"""
# import all the necessary modules
import arcgis
from arcgis.gis import GIS
import arcpy
import logging
import csv
import os
import sys
import time
import configparser
import datetime
from datetime import datetime
from logging import handlers


# Logging function to establish where script logging will occur.
def logging_start(name):
    try:
        master_log = logging.getLogger()
        # Change logging level here (CRITICAL, ERROR, WARNING, INFO or DEBUG)
        master_log.setLevel(logging.INFO)

        if name.endswith('.py'):
            fname = name[:-3]
        else:
            fname = name
            pass

        # Logging variables
        max_bytes = 250000
        backup_count = 1  # Max number appended to log files when MAX_BYTES reached
        log_file = os.path.abspath(os.path.dirname(sys.argv[0])) + os.sep + 'Logs' + os.sep + fname + '.txt'

        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

        fh = logging.handlers.RotatingFileHandler(log_file, 'a', max_bytes, backup_count)
        # Change logging level here for log file (CRITICAL, ERROR, WARNING, INFO or DEBUG)
        fh.setLevel(logging.INFO)
        fh.setFormatter(formatter)
        master_log.addHandler(fh)

        return master_log

    except:
        error = 'Error: %s %s' % (sys.exc_info()[0], sys.exc_info()[1])
        raise error


# Parse through config file for all license types, workspace, output oracle table.
def get_config(location, name):
    try:
        config = configparser.ConfigParser()
        format_name = name[:-3]
        config.read(location + os.sep + format_name + '.cfg')
        agol_url = config.get('URL', 'agol_org')
        user_name = config.get('Credentials', 'user_name')
        pass_word = config.get('Credentials', 'pass_word')
        project_location = config.get('Project', 'location')
        organization = config.get('Sharing', 'org')
        everyone = config.get('Sharing', 'everyone')
        groups = config.get('Sharing', 'groups')
        ago_folder = config.get('Sharing', 'folder')
        logger.info('Parsed all variables from config file.')
        return agol_url, user_name, pass_word, project_location, organization, everyone, groups, ago_folder

    except configparser.Error as error:
        logger.critical('Check get config function: %s' % error)
        logger.critical('Check your config file!')


# Main script to call functions & execute publishing process
if __name__ == "__main__":
    # Auto Determine where the file location the script was placed, establish location, name, output csv
    scriptLocation = os.path.abspath(os.path.dirname(sys.argv[0])) + os.sep + 'Config'
    scriptName = os.path.basename(sys.argv[0])
    csv_path = os.path.abspath(os.path.dirname(sys.argv[0])) + os.sep + 'Logs\AGO_Pro_Update_Times.csv'
    file_exists = os.path.isfile(csv_path)

    # Start Logging
    logger = logging_start(scriptName)
    logger.info('**** Script: %s, was started. ****' % scriptName)
    print('**** Script: %s, was started. ****' % scriptName)
    start_time = time.strftime('%X %x %Z')

    # Parse through config file
    portal, user, password, project, shrOrg, shrEveryone, shrGroups, agol_folder = \
        get_config(scriptLocation, scriptName)

    # Set the path to the project
    prjPath = project

    # Local paths to create temporary content
    relPath = sys.path[0] + '/' + 'tempDir'

    # Set your environment and read in maps from ArcGIS Pro
    try:
        arcpy.env.overwriteOutput = True
        prj = arcpy.mp.ArcGISProject(prjPath)
        mp = prj.listMaps()
    except (arcpy.ExecuteError, arcpy.ExecuteWarning) as e:
        print(e)
        logger.error('Could not Open Project and list maps. Check your project path. %s' % e)
        print('Could not Open Project and list maps. Check your project path. %s' % e)
        logger.critical('---- Script Exited Before Finishing ----')
        sys.exit('---- Script Exited Before Finishing ----Could not connect to Pro Project')

    # Login to an existing organization
    try:
        gis = GIS(portal, user, password)
        logger.info('Successfully connected to %s' % gis)
        print('Successfully connected to %s' % gis)
    except RuntimeError as e:
        logger.critical('Please check your url in %s.cfg' % (scriptName[:-3]))
        logger.critical('Please check your credentials in %s.cfg' % (scriptName[:-3]))
        logger.critical('---- Script Exited Before Finishing ----')
        sys.exit('---- Script Exited Before Finishing ----Could not connect to ArcGIS Online')

    # Loop through each map within the Pro Project.  Make sure map name is identical to feature service rest URL set
    # for the service
    for pro_map in mp:
        logger.info('Processing "%s"...' % str(pro_map.name))
        print('Processing "%s"...' % str(pro_map.name))

        # Set varialbes for sd draft and sd
        draftName = str(pro_map.name) + '.sddraft'
        sdName = str(pro_map.name) + '.sd'
        sddraft = os.path.join(relPath, draftName)
        sd = os.path.join(relPath, sdName)
        sd_fs_name = str(pro_map.name)

        # If output csv that logs publishing times exists, open it.  If not, create & write header.
        if file_exists is True:
            output_file = open(csv_path, 'a')
        else:
            output_file = open(csv_path, 'a')
            output_file.write('LogTime, Org, Service, Type, Duration(Min:Sec:Millsec)\n')
            print('Writing header...')

        # Create SD Draft
        try:
            sharing_draft = pro_map.getWebLayerSharingDraft("HOSTING_SERVER", "FEATURE", sd_fs_name)
            sharing_draft.exportToSDDraft(sddraft)
            # Legacy
            # The arcpy.sharing module was introduced at ArcGIS Pro 2.2 to provide a better experience when
            # sharing web layers over the previously existing function CreateWebLayerSDDraft.
            # arcpy.mp.CreateWebLayerSDDraft(pro_map, sddraft, sd_fs_name,'MY_HOSTED_SERVICES','FEATURE_ACCESS',
            # True, True)
            logger.info('SD File Created.')
            print('SD File Created.')
        except (arcpy.ExecuteError, arcpy.ExecuteWarning) as e:
            logger.error('Could not create SDDraft. Check permissions to script folder: %s' % e)
            sys.exit()
        except RuntimeError as e:
            logger.error('Need to have a user logged into a default Portal (ArcGIS Online or Enterprise); even if the'
                         'program is closed, make sure a user is always logged in.')

        # Stage service in temporary locationc
        try:
            arcpy.StageService_server(sddraft, sd)
        except (arcpy.ExecuteError, arcpy.ExecuteWarning) as e:
            logger.error('Could not stage service. Check staging location: %s' % e)

        logger_key = 0

        # Find the SD, update it, publish /w overwrite and set sharing and metadata
        try:
            sdItem = gis.content.search("{} AND owner:{}".format(sd_fs_name, user), item_type="Service Definition")[0]
            sc = datetime.now()  # Current Datetime
            sdItem.update(data=sd)
            last = datetime.now() - sc  # Difference in time

            # Write publishing time to output csv
            org = str(gis).split("@")[1].split("//")[1].split(".")[0]
            output = str(time.strftime('%X %x')) + ',' + org + ',' + str(pro_map.name) + ',Overwriting SD File,' + \
                str(last) + '\n'
            output_file.write(output)
        except IndexError as e:
            logger.warning('Item is not published, adding SDE to AGOL: %s' % e)
            print('Item is not published, adding SDE to AGOL: %s' % e)
            logger_key = 1

            # Add item as service definition
            sc = datetime.now()  # Current Datetime
            try:
                sdItem = gis.content.add({'title': sd_fs_name}, data=sd, folder=agol_folder)
            except gis.ExecuteError as e:
                logger.error('Error: %s' % e)
            last = datetime.now() - sc  # Difference in time

            # Write publishing time to output csv
            org = str(gis).split("@")[1].split("//")[1].split(".")[0]
            output1 = str(time.strftime('%X %x')) + ',' + org + ',' + str(pro_map.name) + ',Add New SD,' + str(last) + \
                '\n'
            output_file.write(output1)

        # Publish/Overwrite feature service and share according to sharing above.
        try:
            if logger_key == 0:
                logger.info('Overwriting service: %s...' % pro_map.name)
                print('Overwriting service: %s...' % pro_map.name)
            else:
                logger.info('Publishing service: %s...' % pro_map.name)
                print('Publishing service: %s...' % pro_map.name)
            sc = datetime.now()  # Current Datetime
            fs = sdItem.publish(overwrite=True)
            last = datetime.now() - sc  # Difference in time

            # Write publishing time to output csv
            org = str(gis).split("@")[1].split("//")[1].split(".")[0]
            output = str(time.strftime('%X %x')) + ',' + org + ',' + str(pro_map.name) + ',Publishing,' + str(last) + \
                '\n'
            output_file.write(output)

        except:
            logger.error('Could not overwrite service.')

        try:
            fs.share(org=shrOrg, everyone=shrEveryone, groups=shrGroups)
            logger.info('Sharing: Org: %s, Everyone %s, Groups: %s' % (shrOrg, shrEveryone, shrGroups))
            print('Sharing: Org: %s, Everyone %s, Groups: %s' % (shrOrg, shrEveryone, shrGroups))
        except:
            logger.error('Could not share service.')

        logger.info('-* Layer "%s" has been published. *-' % str(pro_map.name))
        print('-* Layer "%s" has been published. *-' % str(pro_map.name))

        # Close output csv for logging time to publish.
        output_file.close()

    logger.info('---- Script: %s completed. ----' % scriptName)
    print('---- Script: %s completed. ----' % scriptName)
